# تنظیمات دقیق Bonto

## Create New App
- Template: **Node.js App**
- App Name: `Nooshad School`
- Subdomain: `noshad` (یا نام آزاد خودت)

## Project
فایل‌های این ZIP را در ریشه پروژه قرار بده.

## Start
`npm start`

## Environment Variables
- `NODE_ENV=production`
- `SESSION_SECRET=` یک رشته تصادفی طولانی
- `DATA_DIR=` مسیر Persistent Storage برای دیتابیس
- `UPLOAD_DIR=` مسیر Persistent Storage برای تصاویر

اگر Bonto برای این دو مسیر مقدار اختصاصی نمی‌خواهد، مقدار پیش‌فرض پروژه یعنی `data` و `public/uploads` را نگه دار.

## بعد از Deploy
1. دامنه را باز کن.
2. `/setup` را باز کن.
3. حساب مالک را بساز.
4. از پنل مالک کلاس و درس بساز.
5. معلم و دانش‌آموز بساز.
6. از «تخصیص آموزشی» معلم + کلاس + درس را متصل کن.
7. با حساب معلم وارد شو و نمره ثبت کن.
8. نمره را تغییر بده.
9. با حساب معاون وارد شو و Audit Log را بررسی کن.
10. با حساب دانش‌آموز وارد شو و کارنامه و میانگین را بررسی کن.
